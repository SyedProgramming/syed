Education data columns:
schema name : education
table name : saer_dataset
partitions : 2016-17, 2017-18,2018-19
columns:
school_ref_num
school_name
total_year12_pupils_elgible_for_inclusion
per_year12_pupils_achieving_5+_gcse_grades_A_C
per_year12_pupils_achieving_5+_gcse_grades_A_C_eng_math
total_year12_pupils_A_level
per_year12_pupils_achieving_3+_gcse_grades_A_C
per_year12_pupils_achieving_2+_gcse_grades_A_E


Analysis:
1. Select total# of schools
2. Select maximum number of students from each school
3. Select top 5 schools eligble for inclusion
4. select top5 school acheiving5+ gcse grades
5. select  top5 school acheiving5+ gcse grades including eng and math
6. select top5 schools of a level
7. select school having 3+ grades
8. select school having 2+ grades


ssh root@127.0.0.1 -p2222
Hadoop_786@

Ambari:
admin
Hadoop_786@


[root@sandbox-hdp ~]# mkdir education_dataset
[root@sandbox-hdp ~]# pwd
/root
[root@sandbox-hdp ~]# ls -lrt /root/education_dataset
total 0
[root@sandbox-hdp ~]#

************* Avoid above lines ****************

[root@sandbox-hdp education_dataset]# hdfs dfs -mkdir -p /user/hadoop/datasets/education
[root@sandbox-hdp education_dataset]# hdfs dfs -put /root/education_dataset/saer_2016_17.csv /user/hadoop/datasets/education/
                                      hdfs dfs -put /root/education_dataset/saer_2017_18.csv /user/hadoop/datasets/education/
                                      hdfs dfs -put /root/education_dataset/saer_2018_19.csv /user/hadoop/datasets/education/

************************************************************************************************************************************************************************************************************************************************
beeline -u 'jdbc:hive2://sandbox-hdp.hortonworks.com:2181/;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hiveserver2'
SET hive.execution.engine=mr;


CREATE DATABASE education LOCATION '/user/hadoop/education';

CREATE TABLE IF NOT EXISTS education.saer_dataset ( school_ref_num int, school_name string, total_year12_pupils_elgible_for_inclusion int, per_year12_pupils_achieving_5plus_gcse_grades_A_C double, per_year12_pupils_achieving_5plus_gcse_grades_A_C_eng_math double, total_year12_pupils_A_level int, per_year12_pupils_achieving_3plus_gcse_grades_A_C double, per_year12_pupils_achieving_2plus_gcse_grades_A_E double )
PARTITIONED BY (year string)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
LINES TERMINATED BY '\n'
STORED AS TEXTFILE
LOCATION '/user/hadoop/education/saer_dataset';

load data inpath '/user/hadoop/datasets/education/saer_2016_17.csv' into table education.saer_dataset partition (year='2016_17');
load data inpath '/user/hadoop/datasets/education/saer_2017_18.csv' into table education.saer_dataset partition (year='2017_18');
load data inpath '/user/hadoop/datasets/education/saer_2018_19.csv' into table education.saer_dataset partition (year='2018_19');


msck repair table education.saer_dataset;



SELECT school_name, COUNT(*) AS TOTAL_NUMBER_OF_SCHOOLS FROM education.saer_dataset WHERE year='2016_17';
SELECT school_name, COUNT(*) AS TOTAL_NUMBER_OF_SCHOOLS FROM education.saer_dataset WHERE year='2017_18';
SELECT school_name, COUNT(*) AS TOTAL_NUMBER_OF_SCHOOLS FROM education.saer_dataset WHERE year='2018_19';


SELECT school_name, total_year12_pupils_elgible_for_inclusion AS TOP_5_SCHOOLS_ELIGBLE_FOR_INCLUSION FROM education.saer_dataset WHERE year='2016_17' ORDER BY TOP_5_SCHOOLS_ELIGBLE_FOR_INCLUSION DESC LIMIT 5;
SELECT school_name, total_year12_pupils_elgible_for_inclusion AS TOP_5_SCHOOLS_ELIGBLE_FOR_INCLUSION FROM education.saer_dataset WHERE year='2017_18' ORDER BY TOP_5_SCHOOLS_ELIGBLE_FOR_INCLUSION DESC LIMIT 5;
SELECT school_name, total_year12_pupils_elgible_for_inclusion AS TOP_5_SCHOOLS_ELIGBLE_FOR_INCLUSION FROM education.saer_dataset WHERE year='2018_19' ORDER BY TOP_5_SCHOOLS_ELIGBLE_FOR_INCLUSION DESC LIMIT 5;


SELECT school_name, per_year12_pupils_achieving_5plus_gcse_grades_A_C AS TOP_5_SCHOOLS_ACHIEVING_5_PLUS_GRADES FROM education.saer_dataset WHERE year='2016_17' ORDER BY TOP_5_SCHOOLS_ACHIEVING_5_PLUS_GRADES DESC LIMIT 5;
SELECT school_name, per_year12_pupils_achieving_5plus_gcse_grades_A_C AS TOP_5_SCHOOLS_ACHIEVING_5_PLUS_GRADES FROM education.saer_dataset WHERE year='2017_18' ORDER BY TOP_5_SCHOOLS_ACHIEVING_5_PLUS_GRADES DESC LIMIT 5;
SELECT school_name, per_year12_pupils_achieving_5plus_gcse_grades_A_C AS TOP_5_SCHOOLS_ACHIEVING_5_PLUS_GRADES FROM education.saer_dataset WHERE year='2018_19' ORDER BY TOP_5_SCHOOLS_ACHIEVING_5_PLUS_GRADES DESC LIMIT 5;


SELECT school_name, per_year12_pupils_achieving_5plus_gcse_grades_A_C_eng_math AS TOP_5_SCHOOLS_ACHIEVING_5_PLUS_GRADES_ENG_MATH FROM education.saer_dataset WHERE year='2016_17' ORDER BY TOP_5_SCHOOLS_ACHIEVING_5_PLUS_GRADES_ENG_MATH DESC LIMIT 5;
SELECT school_name, per_year12_pupils_achieving_5plus_gcse_grades_A_C_eng_math AS TOP_5_SCHOOLS_ACHIEVING_5_PLUS_GRADES_ENG_MATH FROM education.saer_dataset WHERE year='2017_18' ORDER BY TOP_5_SCHOOLS_ACHIEVING_5_PLUS_GRADES_ENG_MATH DESC LIMIT 5;
SELECT school_name, per_year12_pupils_achieving_5plus_gcse_grades_A_C_eng_math AS TOP_5_SCHOOLS_ACHIEVING_5_PLUS_GRADES_ENG_MATH FROM education.saer_dataset WHERE year='2018_19' ORDER BY TOP_5_SCHOOLS_ACHIEVING_5_PLUS_GRADES_ENG_MATH DESC LIMIT 5;

SELECT school_name, per_year12_pupils_achieving_2plus_gcse_grades_A_E AS LEAST_5_PERFORMMED_SCHOOLS FROM education.saer_dataset WHERE year='2016_17' ORDER BY LEAST_5_PERFORMMED_SCHOOLS ASC LIMIT 5;
SELECT school_name, per_year12_pupils_achieving_2plus_gcse_grades_A_E AS LEAST_5_PERFORMMED_SCHOOLS FROM education.saer_dataset WHERE year='2017_18' ORDER BY LEAST_5_PERFORMMED_SCHOOLS ASC LIMIT 5;
SELECT school_name, per_year12_pupils_achieving_2plus_gcse_grades_A_E AS LEAST_5_PERFORMMED_SCHOOLS FROM education.saer_dataset WHERE year='2018_19' ORDER BY LEAST_5_PERFORMMED_SCHOOLS ASC LIMIT 5;



************************************************************************************************************************************************************************************************************************************************
